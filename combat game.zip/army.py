"""
__author__ = "Kuan Jun Qiang"
"""
from abc import ABC, abstractmethod
from stack_adt import ArrayStack
from queue_adt import CircularQueue

class Fighter(ABC):
    def __init__(self, life: int, experience: int) -> None:
        "purpose: to initialise the life and experience"
        "life and experience must be ≥ 0."
        if life < 0 or experience < 0:
            raise ValueError("life and experience must be greater or equal to 0")
        self.life = life
        self.experience = experience
        pass

    def is_alive(self) -> bool:
        "purpose: to return boolean True if the fighter's life is greater than 0 else return boolean False"
        return self.life > 0
        
    def lose_life(self, lost_life: int) -> None:
        "purpose: decreases the life of the Fighter by the amount indicated by lost life."
        "lost_life must >= 0"
        if lost_life < 0:
            raise ValueError("lost_life must be greater or equal to 0") 
        self.life -= lost_life   
        pass

    def get_life(self) -> int:
        "purpose: returns the fighter's life."
        return self.life

    def gain_experience(self, gained_experience: int) -> None:
        "purpose: increases the experience of the Fighter by the amount indicated by gained_experience."
        "gained_experience must be ≥ 0"
        if gained_experience < 0: 
            raise ValueError("gain_experience must be greater or equal to 0")
        self.experience += gained_experience           
        pass

    def get_experience(self) -> int:
        "purpose: returns the experience of the Fighter. "
        return self.experience

    @abstractmethod
    def get_speed(self) -> int:
        pass

    @abstractmethod
    def get_cost(self) -> int:
        pass
        
    @abstractmethod
    def get_attack_damage(self) -> int:
        pass

    @abstractmethod
    def defend(self, damage: int) -> None:
        "purpose: Evaluates the life lost after defence expression and changes life accordingly"
        "damage must be >=0"
        if damage < 0:
            raise ValueError("damage must be greater or equal to 0")
        pass

    @abstractmethod
    def get_unit_type(self) -> str:
        pass

    @abstractmethod
    def __str__(self) -> str:
        pass  

class Soldier(Fighter):
    def __init__(self, life: int = 3, experience: int = 0) -> None:
        Fighter.__init__(self, life, experience)
        self.cost = 1

    def get_unit_type(self) -> str:
        return "Soldier"

    def get_speed(self) -> int:
        return 1 + self.experience

    def get_cost(self) -> int:
        return self.cost

    def get_attack_damage(self) -> int:
        return 1 + self.experience

    def defend(self, damage: int) -> None:
        if damage > self.experience:
            self.lose_life(1)

    def __str__(self) -> str:
        return "Soldier's life = " + str(self.life) + " and experience = " + str(self.experience)

class Archer(Fighter):
    def __init__(self, life: int = 3, experience: int = 0) -> None:
        Fighter.__init__(self, life, experience)
        self.cost = 2

    def get_unit_type(self) -> str:
        return "Archer"
        
    def get_speed(self) -> int:
        return 3

    def get_cost(self) -> int:
        return self.cost

    def get_attack_damage(self) -> int:
        return 1 + self.experience

    def defend(self, damage: int) -> None:
        self.lose_life(1)

    def __str__(self) -> str:
        return "Archer's life = " + str(self.life) + " and experience = " + str(self.experience)

class Cavalry(Fighter):
    def __init__(self, life: int = 4, experience: int = 0) -> None:
        Fighter.__init__(self, life, experience)
        self.cost = 3

    def get_unit_type(self) -> str:
        return "Cavalry"
        
    def get_speed(self) -> int:
        return 2

    def get_cost(self) -> int:
        return self.cost

    def get_attack_damage(self) -> int:
        return 2*self.experience + 1

    def defend(self, damage: int) -> None:
        if damage > self.experience/2:
            self.lose_life(1)

    def __str__(self) -> str:
        return "Cavalry's life = " + str(self.life) + " and experience = " + str(self.experience)

class Army:
    budget = 30
    def _init_(self) -> None:
        self.name = None
        self.force = None
        self.cost = 0

    def __correct_army_given(self, soldiers: int, archers: int, cavalry: int) -> bool:
        cost = soldiers*Soldier.get_cost(self) + archers*Archer.get_cost(self) + cavalry*Cavalry.get_cost(self)
        return cost <= self.budget 

    def __assign_army(self, name:str, sold: int, arch: int, cav: int, formation: int) -> None:
        if formation == 0:
            my_stack = ArrayStack(2)
            self.name = name
            my_stack.push(self.name)

            self.force = ArrayStack(sold+arch+cav)
            for i in range(sold):
                self.force.push(Soldier())
            for i in range(arch):
                self.force.push(Archer())
            for i in range(cav):
                self.force.push(Cavalry())
            
            my_stack.push(self.force)
            
        elif formation == 1:
            my_queue = CircularQueue(2)
            self.name = name
            my_queue.append(self.name)
            
            self.force = CircularQueue(sold+arch+cav)
            for i in range(sold):
                self.force.append(Soldier())
            for i in range(arch):
                self.force.append(Archer())
            for i in range(cav):
                self.force.append(Cavalry())
            
            my_queue.append(self.force)

        pass
            

    def choose_army(self, name: str, formation: int) -> None:
        print("Player" + name + "choose your army as S A C\nwhere S is the number of soldiers\n      A is the number of archers\n      C is the number of cavalries")
        while True:
            s = int(input("\nEnter your number of soldiers: "))
            a = int(input("\nEnter your number of archers: "))
            c = int(input("\nEnter your number of cavalries: "))
            
            if __correct_army_given(s, a, c)==False:
                print("\nPlease input again")
            else:
                __assign_army(name, s, a, c, formation)
                break
    
    def __str__(self) -> str:
        return str(self.force.__str__())
