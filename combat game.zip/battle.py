from army import Archer, Soldier, Cavalry, Army
from stack_adt import Stack, ArrayStack
from queue_adt import Queue, CircularQueue

class Battle:
    
    def gladiatorial_combat(self, player_one: str, player_two: str) -> int:
        "purpose: read army that had been choosed and push to stack"
        player_one = Army().choose_army(player_one,0)
        player_two = Army().choose_army(player_two,0)

        return __conduct_combat(player_one, player_two,0)
    
    def fairer_combat(self, player_one: str, player_two: str) -> int:
        "purpose: read army that had been choosed and append to queue"
        player_one = Army().choose_army(player_one,1)
        player_two = Army().choose_army(player_two,1)

        return __conduct_combat(player_one, player_two,1)

    def __conduct_combat(self, army1: Army, army2: Army, formation: int) -> int:
        "purpose: method that used to indicate winner"

        "if one of the player's army stack is empty then the other player won"
        "if both player's army empty then it's draw"
        if army1.force.is_empty() and army2.force.is_empty():
            return 0
        elif army1.force.is_empty() == False and army2.force.is_empty():
            return 1
        elif army1.force.is_empty() and army2.force.is_empty() == False:
            return 2

        "Used to record result of each combat"
        P1_won = 0
        P2_won = 0

        while True:
            "Used to check if any player's army done the combat"
            if army1.force.is_empty() or army2.force.is_empty():
                if P1_won > P2_won:
                    return 1
                elif P1_won < P2_won:
                    return 2
                else:
                    return 0
            
            if formation ==0:
                P1 = army1.force.pop()
                P2 = army2.force.pop()
            elif formation ==1:
                P1 = army1.force.serve()
                P2 = army2.force.serve()

            "indicate which player's army attack first"
            "greater speed attack first, if same speed, greater attack_damage attack first"
            if P1.get_speed() >P2.get_speed():
                P2.defend(P1.get_attack_damage())
                if P2.is_alive():
                    P1.defend(P2.get_attack_damage())

            elif P1.get_speed() <P2.get_speed():
                P1.defend(P2.get_attack_damage())
                if P1.is_alive():
                    P2.defend(P1.get_attack_damage())
            else:
                if P1.get_attack_damage()> P2.get_attack_damage():
                    P2.defend(P1.get_attack_damage())
                    if P2.is_alive():
                        P1.defend(P2.get_attack_damage())
                
                elif P1.get_attack_damage()< P2.get_attack_damage():
                    P1.defend(P2.get_attack_damage())
                    if P1.is_alive():
                        P2.defend(P1.get_attack_damage())

                elif P1.get_attack_damage() == P2.get_attack_damage():
                    P1.defend(P2.get_attack_damage())
                    P2.defend(P1.get_attack_damage())

            "record every combat and gain experience for the army"
            "if army still alive push to stack"          
            if P1.is_alive() == False and P2.is_alive():
                P2_won +=1
                P2.experience +=1
                if formation ==0:
                    army2.force.push(P2)
                elif formation == 1:
                    army2.force.append(P2)
            elif P1.is_alive() and P2.is_alive()== False:
                P1_won +=1
                P1.experience +=1
                if formation ==0:
                    army1.force.push(P1)
                elif formation == 1:
                    army1.force.append(P1)
            elif P1.is_alive() and P2.is_alive():
                if formation ==0:    
                    army2.force.push(P2)
                    army1.force.push(P1)
                elif formation ==1:
                    army2.force.append(P2)
                    army1.force.append(P1)
